#include "TestService.h"
#include <assert.h>
#include "Service.h"
#include "RepoFileTXT.h"
#include "Animal.h"
#include "Obiect.h"
#include "RepoException.h"
#include <vector>
#include <iostream>
using namespace std;

void TestService::testGetAll()
{
	Service serv;
	RepoFile* repoFile = new RepoFileTXT();
	serv.setRepo(repoFile);
	Animal* p1 = new Animal("1","a", 1, "1", 1,1);
	Obiect* p2 = new Obiect("2","b", 2, "2", 2,"2");
	serv.addAnimal(p1->getCod(),p1->getNume(), p1->getPret(), p1->getData(), p1->getNrExemplare(), p1->getVarsta());
	serv.addObiect(p2->getCod(), p2->getNume(), p2->getPret(), p2->getData(), p2->getNrExemplare(), p2->getDataExpirare());
	vector<Produs*> produse = serv.getAll();
	assert(*produse[0] == *p1);
	assert(*produse[1] == *p2);
}

void TestService::testAnimal()
{
	Service serv;
	RepoFile* repoFile = new RepoFileTXT();
	serv.setRepo(repoFile);
	Animal* p1 = new Animal("1", "a", 1, "1", 1, 1);
	try {
		serv.addAnimal(p1->getCod(), p1->getNume(), p1->getPret(), p1->getData(), p1->getNrExemplare(), p1->getVarsta());
	}
	catch (...) {
		assert(false);
	}
	
	
}

void TestService::testObiect()
{
	Service serv;
	RepoFile* repoFile = new RepoFileTXT();
	serv.setRepo(repoFile);
	Obiect* p2 = new Obiect("2", "b", 2, "2", 2, "2");
	try {
		serv.addObiect(p2->getCod(), p2->getNume(), p2->getPret(), p2->getData(), p2->getNrExemplare(), p2->getDataExpirare());
	}
	catch (...) {
		assert(false);
	}
	assert(*serv.getProdusAtPosition(0) == *p2);
	
}


void TestService::testDeleteProdus()
{
	Service serv;
	RepoFile* repoFile = new RepoFileTXT();
	serv.setRepo(repoFile);
	Animal* p1 = new Animal("1", "a", 1, "1", 1, 1);
	
	serv.addAnimal(p1->getCod(), p1->getNume(), p1->getPret(), p1->getData(), p1->getNrExemplare(), p1->getVarsta());
	
	
	//serv.deleteProdus("2","a");
		//assert(false);
	
	assert(*serv.getProdusAtPosition(0) == *p1);
	serv.deleteProdus(p1->getCod(),p1->getNume());
	
}

void TestService::testFilterByPrice()
{
	Service serv;
	RepoFile* repoFile = new RepoFileTXT();
	serv.setRepo(repoFile);
	Animal* p1 = new Animal("1", "a", 5, "1", 1, 1);
	Obiect* p2 = new Obiect("2", "b", 20, "2", 2, "2");
	serv.addAnimal(p1->getCod(), p1->getNume(), p1->getPret(), p1->getData(), p1->getNrExemplare(), p1->getVarsta());
	serv.addObiect(p2->getCod(), p2->getNume(), p2->getPret(), p2->getData(), p2->getNrExemplare(), p2->getDataExpirare());

	vector<Produs*> filterResult = serv.filterByPrice(0, 4);
	assert(filterResult.size() == 0);
	filterResult = serv.filterByPrice(30, 40);
	assert(filterResult.size() == 0);
	filterResult = serv.filterByPrice(4, 7);
	assert(filterResult.size() == 1);
	assert(*filterResult[0] == *p1);
	filterResult = serv.filterByPrice(10, 28);
	assert(filterResult.size() == 1);
	assert(*filterResult[0] == *p2);
	filterResult = serv.filterByPrice(2, 44);
	assert(filterResult.size() == 2);
	assert(*filterResult[0] == *p1);
	assert(*filterResult[1] == *p2);
}


void TestService::testCumpara()
{
	Service serv;
	RepoFile* repoFile = new RepoFileTXT();
	serv.setRepo(repoFile);
	double pretTotal;
	Animal* p1 = new Animal("1", "a", 1, "1", 1, 1);
	
	serv.addAnimal(p1->getCod(), p1->getNume(), p1->getPret(), p1->getData(), p1->getNrExemplare(), p1->getVarsta());
	assert(serv.cumpara("ciocolata", 1, pretTotal) == -2);
	assert(serv.cumpara(p1->getNume(), 600, pretTotal) == -1);
	//cout << serv.cumpara(p1->getNume(), 50, pretTotal);
	assert(serv.cumpara(p1->getNume(), 50, pretTotal) == -1);
	//cout << pretTotal;
	assert(pretTotal == 0);
	//assert(serv.getProdusAtPosition(0)->getCantitate() == 450);
}

void TestService::testcauta()
{
	Service serv;
	RepoFile* repoFile = new RepoFileTXT();
	serv.setRepo(repoFile);
	Animal* p1 = new Animal("1", "a", 1, "1", 1, 1);

	serv.addAnimal(p1->getCod(), p1->getNume(), p1->getPret(), p1->getData(), p1->getNrExemplare(), p1->getVarsta());
	vector <Produs*> pr = serv.cautare("b");
	assert(pr.size()==0);
	pr = serv.cautare("a");
	assert(pr.size() == 1);
	assert(*pr[0] == *p1);



}

void TestService::testLive()
{
	Animal* a1=new Animal("554", "papagal", 100, "01.04.2020", 5, 2);
	Obiect* a2=new Obiect("554", "mancare_pesti", 30, "11.12.2019", 12, "01.01.2022");
	Animal* a3=new Animal("555", "papagal", 60, "03.05.2020", 1, 3);
	Animal* a4=new Animal("554", "papagal", 70, "07.03.2020", 3, 3);
	Obiect* a5=new Obiect("554", "mancare_pesti", 30, "11.12.2019", 20, "01.01.2022");
	Service service;
	RepoFile* repoFile = new RepoFileTXT();
	service.setRepo(repoFile);

	service.addAnimal(a1->getCod(), a1->getNume(), a1->getPret(), a1->getData(), a1->getNrExemplare(), a1->getVarsta());
	service.addObiect(a2->getCod(), a2->getNume(), a2->getPret(), a2->getData(), a2->getNrExemplare(), a2->getDataExpirare());
	service.addAnimal(a3->getCod(), a3->getNume(), a3->getPret(), a3->getData(), a3->getNrExemplare(), a3->getVarsta());
	
	assert(service.size() == 3);
	assert(*service.getProdusAtPosition(0) == *a1);
	assert(*service.getProdusAtPosition(1) == *a2);
	assert(*service.getProdusAtPosition(2) == *a3);
	
	service.addAnimal(a4->getCod(), a4->getNume(), a4->getPret(), a4->getData(), a4->getNrExemplare(), a4->getVarsta());
	
	assert(service.size() == 3);
	assert(service.getProdusAtPosition(0)->getCod() == a1->getCod());
	assert(service.getProdusAtPosition(0)->getCod() == a1->getCod());
	assert(service.getProdusAtPosition(0)->getNume() == a1->getNume());
	
	assert(service.getProdusAtPosition(0)->getNrExemplare() == 8);
	assert(*service.getProdusAtPosition(1) == *a2);
	assert(*service.getProdusAtPosition(2) == *a3);

	service.addObiect(a5->getCod(), a5->getNume(), a5->getPret(), a5->getData(), a5->getNrExemplare(), a5->getDataExpirare());
	assert(service.size() == 3);
	assert(service.getProdusAtPosition(0)->getCod() == a1->getCod());
	assert(service.getProdusAtPosition(0)->getNume() == a1->getNume());
	assert(service.getProdusAtPosition(0)->getNrExemplare() == 8);
	assert(service.getProdusAtPosition(1)->getCod() == a2->getCod());
	assert(service.getProdusAtPosition(0)->getNume() == a3->getNume());
	//cout << service.getProdusAtPosition(2)->getNrExemplare()<<endl;
	assert(service.getProdusAtPosition(1)->getNrExemplare() == 32);
	assert(*service.getProdusAtPosition(2) == *a3);
	cout << "Teste live" << endl;

}

TestService::TestService()
{
}

TestService::~TestService()
{
}

void TestService::testAll()
{
	this->testGetAll();

	this->testAnimal();
	this->testObiect();
	
	this->testDeleteProdus();

	this->testFilterByPrice();
	
	this->testCumpara();
	this->testcauta();
	this->testLive();
}
