#pragma once
#include "ValidatorProdus.h"

class ValidatorObiect : public ValidatorProdus {
public:
	ValidatorObiect();
	~ValidatorObiect();
	void validate(Produs* p);
};