#pragma once
#include "User.h"
#include <vector>

using namespace std;

class RepoUser {
private:
	vector<User> users;
public:
	RepoUser();
	
	~RepoUser();
	
	bool find(User&);
	void remove(User&);
	vector<User> getAll();

};


