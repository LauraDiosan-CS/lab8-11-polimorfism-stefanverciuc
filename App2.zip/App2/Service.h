#pragma once
#include "RepoFile.h"
#include "RepoUser.h"
class Service {
private:
	RepoFile* repo;
	//RepoUser* users;
public:
	Service();
	Service(RepoFile* repo);
	~Service();

	bool login(string user, string password, RepoUser* users);
	int size();
	vector<Produs*> getAll();
	Produs* getProdusAtPosition(int pos);
	void addAnimal(string cod, string nume, int pret, string data, int nr, int varsta);
	void addObiect(string cod, string nume, int pret, string data, int nr,string dataExpirare);
	void updateAnimal(string numeVechi, string numeNou, string codVechi, string codNou, int pret, string data, int nr, int varsta);
	void updateObiect(string numeVechi, string numeNou, string codVechi, string codNou, int pret, string data, int nr, string dataExpirare);
	void deleteProdus(string cod, string nume);

	vector<Produs*> filterByPrice(int lowerBound, int upperBound);
	vector<Produs*> sortByQuantity();
	int cumpara(string nume, int cantitate, double& pretTotal);
	int returneaza(string nume, int cantitate);
	vector<Produs*> cautare(string key);

	void loadFromFile();
	void saveToFile();
	void setFileName(string fileName);
	void setRepo(RepoFile* repo);
};

bool compareByQuantity(Produs* p1, Produs* p2);