#pragma once
#include "Produs.h"

class Obiect : public Produs {
private:
	string dataExpirare;
public:
	Obiect();
	Obiect(string cod, string nume, int pret, string data, int nrExxemplare, string dataExpirare);
	Obiect(const Obiect& p);
	~Obiect();

	Produs* clone();

	string getDataExpirare();
	void setDataExpirare(string dataExpirare);
	Obiect& operator=(const Obiect& p);
	bool operator==(const Obiect& p);
	string toString(string delim);
};