#include "TestAnimal.h"
#include <assert.h>
#include "Animal.h"
#include "Util.h"
#include <iostream>

using namespace std;

void TestAnimal::testAll()
{
	this->testImplicitConstructor();
	this->testConstructorWithParameters();
	this->testCopyConstructor();
	this->testClone();
	this->testGetVarsta();
	this->testSetVarsta();;
	this->testAssignmentOperator();
	this->testEqualityOperator();
	this->testToString();
}

void TestAnimal::testImplicitConstructor()
{
	Animal p;
	assert(p.getNume().empty());
	assert(p.getPret() == 0);
}

void TestAnimal::testConstructorWithParameters()
{
	Animal p("123", "caine", 3, "03.03.2020", 1, 3);
	assert(p.getNume() == "caine");
	assert(p.getPret() == 3);
}

void TestAnimal::testCopyConstructor()
{
	Animal p1("123", "caine", 3, "03.03.2020", 1, 3);
	Animal p2(p1);
	assert(p2.getNume() == p1.getNume());
	assert(p2.getPret() == p1.getPret());
}

void TestAnimal::testClone()
{
	Animal p("123", "caine", 3, "03.03.2020", 1, 3);
	Animal* pClone = (Animal*)p.clone();
	assert(p == *pClone);
	assert(&p != pClone);
}

void TestAnimal::testGetVarsta()
{
	Animal p("123", "caine", 3, "03.03.2020", 1, 3);
	assert(p.getNume() == "caine");
}

void TestAnimal::testSetVarsta()
{
	Animal p;
	p.setNume("caine");
	assert(p.getNume() == "caine");
}

void TestAnimal::testAssignmentOperator()
{
	Animal p1("123", "caine", 3, "03.03.2020", 1, 3);
	Animal p2;
	p2 = p1;
	assert(p2.getNume() == p1.getNume());
	assert(p2.getPret() == p1.getPret());
}

void TestAnimal::testEqualityOperator()
{
	Animal p1("123", "caine", 3, "03.03.2020", 1, 3);
	Animal p2 = p1;
	assert(p1 == p2);
	p2.setNume("briosa");
	assert(!(p1 == p2));
	p2.setNume(p1.getNume());
	assert(p1 == p2);
	p2.setPret(10);
	assert(!(p1 == p2));
	p2.setPret(p1.getPret());
	assert(p1 == p2);
}

void TestAnimal::testToString()
{
	Animal p("123", "caine", 3, "03.03.2020", 1, 3);
	//cout << p.toString(" ");
	assert(p.toString(" ") == "Animal 123 caine 3 03.03.2020 1 3");
	assert(p.toString(",") == "Animal,123,caine,3,03.03.2020,1,3");
}
