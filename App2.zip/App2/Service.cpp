#include "Service.h"
#include "Animal.h"
#include "Obiect.h"
#include <algorithm>
#include "RepoException.h"
#include "ValidationException.h"
#include "ReadFromFileException.h"

using namespace std;

Service::Service()
{
	this->repo = NULL;
}

Service::Service(RepoFile* repo)
{
	this->repo = repo;
}

Service::~Service()
{
	if (this->repo != NULL)
	{
		delete this->repo;
	}
}

bool Service::login(string user, string password, RepoUser* users)
{
	vector<User> u = users->getAll();
	User U(user, password);
	for (User R : u)
		if (R == U)
			return true;
	return false;

}

int Service::size()
{
	vector<Produs*> all = this->repo->getAll();
	return all.size();
}

vector<Produs*> Service::getAll()
{
	return this->repo->getAll();
}

Produs* Service::getProdusAtPosition(int pos) throw(RepoException)
{
	return this->repo->getProdus(pos);
}

void Service::addAnimal(string cod, string nume, int pret, string data, int nr, int varsta)
throw(ValidationException, RepoException)
{
	Animal* pd = new Animal(cod, nume, pret, data, nr, varsta);
	this->repo->addProdus(pd);
}

void Service::addObiect(string cod, string nume, int pret, string data, int nr, string dataExpirare)
throw(ValidationException, RepoException)
{
	Obiect* ps = new Obiect(cod, nume, pret, data, nr, dataExpirare);
	this->repo->addProdus(ps);
}

void Service::updateAnimal(string numeVechi, string numeNou, string codVechi, string codNou, int pret, string data, int nr, int varsta)
throw(ValidationException, RepoException)
{
	Produs* pVechi = new Produs(codVechi, numeVechi, 0, "", 0);
	Animal* pNou = new Animal(codNou, numeNou, pret, data, nr, varsta);
	this->repo->updateProdus(pVechi, pNou);
}

void Service::updateObiect(string numeVechi, string numeNou, string codVechi, string codNou, int pret, string data, int nr, string dataExpirare)
throw(ValidationException, RepoException)
{
	Produs* pVechi = new Produs(codVechi, numeVechi, 0, "", 0);
	Obiect* pNou = new Obiect(codNou, numeNou, pret, data, nr, dataExpirare);
	this->repo->updateProdus(pVechi, pNou);
}

void Service::deleteProdus(string cod, string nume) throw(RepoException)
{
	Produs* p = new Produs(cod, nume, 0, "", 0);
	this->repo->deleteProdus(p);
}

vector<Produs*> Service::filterByPrice(int lowerBound, int upperBound)
{
	vector<Produs*> produse = this->repo->getAll();
	vector<Produs*> result;
	for (Produs* p : produse)
	{
		if (p->getPret() >= lowerBound && p->getPret() <= upperBound)
		{
			result.push_back(p->clone());
		}
	}
	return result;
}

vector <Produs*> Service::cautare(string key)
{
	vector<Produs*> produse = this->repo->getAll();
	vector<Produs*> result;
	for (Produs* p : produse)
	{
		if (p->getNume() == key or p->getData() == key)
		{
			result.push_back(p->clone());
		}
	}
	return result;
}

bool compareByQuantity(Produs* p1, Produs* p2)
{
	return p1->getNrExemplare() < p2->getNrExemplare();
}

vector<Produs*> Service::sortByQuantity()
{
	vector<Produs*> produse = this->repo->getAll();
	sort(produse.begin(), produse.end(), compareByQuantity);
	return produse;
}

int Service::cumpara(string nume, int cantitate, double& pretTotal)
{
	pretTotal = 0;
	vector<Produs*> produse = this->repo->getAll();
	for (Produs* p : produse)
	{
		if (p->getNume() == nume)
			if (p->getNrExemplare() >= cantitate)
			{
				pretTotal = p->getPret() * cantitate;
				p->setNrExemplare(p->getNrExemplare() - cantitate);
				this->saveToFile();
				return 0;
			}
			else
			{
				return -1;
			}
	}
	return -2;
}

int Service::returneaza(string nume, int cantitate)
{
	vector<Produs*> produse = this->repo->getAll();
	for (Produs* p : produse)
	{
		if (p->getNume() == nume)
		{
			p->setNrExemplare(p->getNrExemplare() + cantitate);
			this->saveToFile();
			return 0;
		}
	}
	return -1;
}

void Service::loadFromFile() throw(ReadFromFileException)
{
	this->repo->loadFromFile();
}

void Service::saveToFile()
{
	this->repo->saveToFile();
}

void Service::setFileName(string fileName)
{
	this->repo->setFileName(fileName);
}

void Service::setRepo(RepoFile* repo)
{
	this->repo = repo;
}
