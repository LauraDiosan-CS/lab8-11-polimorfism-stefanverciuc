#include "Animal.h"
#include "Util.h"

Animal::Animal() : Produs()
{
}

Animal::Animal(string cod, string nume, int pret, string data, int nrExemplare, int varsta) : Produs(cod, nume, pret,data,nrExemplare)
{
	this->varsta = varsta;
}

Animal::Animal(const Animal& p) : Produs(p)
{
	this->varsta = p.varsta;
}

Animal::~Animal()
{
}

Produs* Animal::clone()
{
	return new Animal(this->cod, this->nume, this->pret, this->data, this->nrExemplare,this->varsta);
}

int Animal ::getVarsta()
{
	return this->varsta;
}

void Animal::setVarsta(int varsta)
{
	this->varsta = varsta;
}

Animal& Animal::operator=(const Animal& p)
{
	Produs::operator=(p);
	this->varsta = p.varsta;
	return *this;
}

bool Animal::operator==(const Animal& p)
{
	return Produs::operator==(p);
}

string Animal::toString(string delim)
{
	return "Animal" + delim + Produs::toString(delim) + delim + to_string(this->varsta);
}
