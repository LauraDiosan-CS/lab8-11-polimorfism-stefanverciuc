#pragma once
class TestService {
private:
    void testGetAll();
    //void testGetProdusAtPosition();
    void testAnimal();
    void testObiect();
    //void testUpdateProdusDulce();
    //void testUpdateProdusSarat();
    void testDeleteProdus();

    void testFilterByPrice();
    void testSortByQuantity();
    void testCumpara();
    void testReturneaza();
    void testcauta();
    void testLive();
public:
    TestService();
    ~TestService();
    void testAll();
};