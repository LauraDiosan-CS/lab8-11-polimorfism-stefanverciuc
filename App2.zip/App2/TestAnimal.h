#pragma once
class TestAnimal {
private:
	void testImplicitConstructor();
	void testConstructorWithParameters();
	void testCopyConstructor();
	void testClone();
	void testGetVarsta();
	void testSetVarsta();
	void testAssignmentOperator();
	void testEqualityOperator();
	void testToString();
public:
	void testAll();
};