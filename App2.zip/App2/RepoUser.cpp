#include "RepoUser.h"
#include <fstream>

RepoUser::RepoUser()
{
	ifstream f("User.txt");
	if (f.is_open())
	{

		string linie;
		string delim = ",";
		while (getline(f, linie))
		{

			int pos = linie.find(delim);
			string user = linie.substr(0, pos);
			linie = linie.erase(0, pos + 1);

			pos = linie.find(delim);
			string parola = linie.substr(0, pos);


			User u(user, parola);
			this->users.push_back(u);
		}
	}
}


RepoUser::~RepoUser() {}



vector<User> RepoUser::getAll()
{
	return this->users;
}

void RepoUser::remove(User& u) {
	int i = 0;
	for (User usr : this->users)
	{
		if (usr == u)
			//delete this->users[i];
		{
			this->users.erase(this->users.begin() + i);
			return;
		}
	}
	
}

bool RepoUser::find(User& u)
{
	for (User usr : this->users)
	{
		if (usr == u)
			return 1;
	}
	return 0;
}