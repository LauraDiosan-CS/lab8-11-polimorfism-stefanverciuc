#pragma once
#include "ValidatorProdus.h"

class ValidatorAnimal : public ValidatorProdus {
public:
	ValidatorAnimal();
	~ValidatorAnimal();
	void validate(Produs* p);
};