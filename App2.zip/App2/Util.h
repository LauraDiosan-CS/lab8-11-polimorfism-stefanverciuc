#pragma once
#include <string>

using namespace std;

string convertDoubleToString(double x);