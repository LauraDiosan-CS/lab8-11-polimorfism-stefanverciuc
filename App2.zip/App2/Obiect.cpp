#include "Obiect.h"
#include "Util.h"

Obiect::Obiect() : Produs()
{
}

Obiect::Obiect(string cod, string nume, int pret, string data, int nrExemplare, string dataExpirare) : Produs(cod, nume, pret, data, nrExemplare)
{
	this->dataExpirare = dataExpirare;
}

Obiect::Obiect(const Obiect& p) : Produs(p)
{
	this->dataExpirare = p.dataExpirare;
}

Obiect::~Obiect()
{
}

Produs* Obiect::clone()
{
	return new Obiect(this->cod, this->nume, this->pret, this->data, this->nrExemplare, this->dataExpirare);
}

string Obiect::getDataExpirare()
{
	return this->dataExpirare;
}

void Obiect::setDataExpirare(string dataExpirare)
{
	this->dataExpirare = dataExpirare;
}

Obiect& Obiect::operator=(const Obiect& p)
{
	Produs::operator=(p);
	this->dataExpirare = p.dataExpirare;
	return *this;
}

bool Obiect::operator==(const Obiect& p)
{
	return Produs::operator==(p);
}

string Obiect::toString(string delim)
{
	return "Obiect" + delim + Produs::toString(delim) + delim + dataExpirare;
}
