
#pragma once
#include "Service.h"
#include "User.h"

class UI {
private:
	Service serv;
	User u;
	bool login();
	
	void displayMenu();
	void chooseFileType();
	void UILoadFromFile();
	void UIAddProdusDulce();
	void UIAddProdusSarat();
	void UIModifyProdus();
	void UIDeleteProdus();
	void UIShowAll();
	void printProduse(vector<Produs*> produse);

	void UIFilterByPrice();
	void UISortByQuantity();
	void UICumpara();
	void UIReturneaza();
	void cautare();
public:
	UI();
	~UI();
	void runUI();
};
