#include "Produs.h"
#include "Util.h"

Produs::Produs()
{
	this->pret = 0;
	this->nrExemplare = 0;
}

Produs::Produs(string cod, string nume, int pret,string data, int nrExemplare)
{
	this->cod = cod;
	this->nume = nume;
	this->pret = pret;
	this->data = data;
	this->nrExemplare = nrExemplare;
}

Produs::Produs(const Produs& p)
{	
	this->cod = p.cod;
	this->nume = p.nume;
	this->pret = p.pret;
	this->data = p.data;
	this->nrExemplare = p.nrExemplare;
}

Produs::~Produs()
{
}

Produs* Produs::clone()
{
	return new Produs(this->cod,this->nume, this->pret,this->data,this->nrExemplare);
}

string Produs::getCod() {
	return this->cod;
}

string Produs::getNume()
{
	return this->nume;
}

int Produs::getPret()
{
	return this->pret;
}

string Produs::getData()
{
	return this->data;
}

int Produs::getNrExemplare()
{
	return this->nrExemplare;
}

void Produs::setCod(string cod)
{
	this->cod = cod;
}

void Produs::setNume(string nume)
{
	this->nume = nume;
}

void Produs::setPret(int pret)
{
	this->pret = pret;
}

void Produs::setData(string data)
{
	this->data = data;
}

void Produs::setNrExemplare(int nrExemplare)
{
	this->nrExemplare = nrExemplare;
}

Produs& Produs::operator=(const Produs& p)
{
	this->cod = p.cod;
	this->nume = p.nume;
	this->pret = p.pret;
	this->data = p.data;
	this->nrExemplare = p.nrExemplare;

	return *this;
}

bool Produs::operator==(const Produs& p)
{
	return this->nume == p.nume && this->cod == p.cod;
}

string Produs::toString(string delim)
{
	return this->cod + delim + this->nume + delim + to_string(this->pret) + delim + this->data +delim + to_string(this->nrExemplare);
}
