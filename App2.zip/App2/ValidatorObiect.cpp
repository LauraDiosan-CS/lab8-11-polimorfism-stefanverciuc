#include "ValidatorObiect.h"
#include "Obiect.h"
#include "ValidationException.h"
//
ValidatorObiect::ValidatorObiect()
{
}

ValidatorObiect::~ValidatorObiect()
{
}

void ValidatorObiect::validate(Produs* p)
{
	ValidatorProdus::validate(p);
	Obiect* pd = (Obiect*)p;
	if (pd->getDataExpirare().empty())
	{
		throw ValidationException("Data de expirare a produsului nu poate fi goala!");
	}
	for (char c : pd->getDataExpirare())
	{
		if (!(c=='.' or isdigit(c)))
		{
			throw ValidationException("Data produsului poate sa contina decat cifre si sa fie de forma ZZ.LL.AAAA!");
		}
	}
}
