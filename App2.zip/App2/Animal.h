#pragma once
#include "Produs.h"

class Animal : public Produs {
private:
	int varsta;
public:
	Animal();
	Animal(string cod, string nume, int pret, string data, int nrExxemplare, int varsta);
	Animal(const Animal& p);
	~Animal();

	Produs* clone();

	int getVarsta();
	void setVarsta(int varsta);
	Animal& operator=(const Animal& p);
	bool operator==(const Animal& p);
	string toString(string delim);
};