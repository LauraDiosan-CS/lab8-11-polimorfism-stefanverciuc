#pragma once
#include <string>

using namespace std;
class Produs {
protected:
	string cod;
	string nume;
	int pret;
	string data;
	int nrExemplare;


public:
	Produs();
	Produs(string cod, string nume, int pret, string data, int nrExemplare);
	Produs(const Produs& p);
	~Produs();

	virtual Produs* clone();

	string getCod();
	string getNume();
	int getPret();
	string getData();
	int getNrExemplare();

	void setCod(string cod);
	void setNume(string nume);
	void setPret(int pret);
	void setData(string data);
	void setNrExemplare(int nrExemplare);

	Produs& operator=(const Produs& p);
	bool operator==(const Produs& p);
	virtual string toString(string delim);
};