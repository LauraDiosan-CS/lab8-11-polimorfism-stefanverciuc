#include "TestObiect.h"
#include <assert.h>
#include "Obiect.h"
#include "Util.h"
#include <iostream>

using namespace std;

void TestObiect::testAll()
{
	this->testImplicitConstructor();
	this->testConstructorWithParameters();
	this->testCopyConstructor();
	this->testClone();
	this->testGetData();
	this->testSetData();;
	this->testAssignmentOperator();
	this->testEqualityOperator();
	this->testToString();
}

void TestObiect::testImplicitConstructor()
{
	Obiect p;
	assert(p.getNume().empty());
	assert(p.getPret() == 0);
}

void TestObiect::testConstructorWithParameters()
{
	Obiect p("123", "caine", 3, "03.03.2020", 1, "3");
	assert(p.getNume() == "caine");
	assert(p.getPret() == 3);
}

void TestObiect::testCopyConstructor()
{
	Obiect p1("123", "caine", 3, "03.03.2020", 1, "3");
	Obiect p2(p1);
	assert(p2.getNume() == p1.getNume());
	assert(p2.getPret() == p1.getPret());
}

void TestObiect::testClone()
{
	Obiect p("123", "caine", 3, "03.03.2020", 1, "3");
	Obiect* pClone = (Obiect*)p.clone();
	assert(p == *pClone);
	assert(&p != pClone);
}

void TestObiect::testGetData()
{
	Obiect p("123", "caine", 3, "03.03.2020", 1, "3");
	assert(p.getNume() == "caine");
}

void TestObiect::testSetData()
{
	Obiect p;
	p.setNume("caine");
	assert(p.getNume() == "caine");
}

void TestObiect::testAssignmentOperator()
{
	Obiect p1("123", "caine", 3, "03.03.2020", 1, "3");
	Obiect p2;
	p2 = p1;
	assert(p2.getNume() == p1.getNume());
	assert(p2.getPret() == p1.getPret());
}

void TestObiect::testEqualityOperator()
{
	Obiect p1("123", "caine", 3, "03.03.2020", 1, "3");
	Obiect p2 = p1;
	assert(p1 == p2);
	p2.setNume("briosa");
	assert(!(p1 == p2));
	p2.setNume(p1.getNume());
	assert(p1 == p2);
	p2.setPret(10);
	assert(!(p1 == p2));
	p2.setPret(p1.getPret());
	assert(p1 == p2);
}

void TestObiect::testToString()
{
	Obiect p("123", "caine", 3, "03.03.2020", 1, "3");
	//cout << p.toString(" ");
	assert(p.toString(" ") == "Obiect 123 caine 3 03.03.2020 1 3");
	assert(p.toString(",") == "Obiect,123,caine,3,03.03.2020,1,3");
}
