// App2.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
//#include "TestProdus.h"
//#include "TestAnimal.h"
//#include "TestObiect.h"
//#include "TestRepoFile.h"
#include "RepoFileCSV.h"
#include "RepoFileTXT.h"
//#include "TestRepoUser.h"
#include "Service.h"
//#include "TestService.h"
#include "UI.h"
#include "TestService.h"

using namespace std;

int main()
{
    /*TestProdus testProdus;
    testProdus.testAll();
    TestAnimal testAnimal;
    testAnimal.testAll();
    TestObiect testObiect;
    testObiect.testAll();

    TestRepoFile testRepoFile;
    testRepoFile.testAll();

    testRepoUser();
    testUser();
    testAll();
    */
    TestService s;
    s.testAll();

    std::cout << "Succesfull test!\n";

    UI ui;
    ui.runUI();

    //cout << "Gata";

    /*RepoFile* repoFile = new RepoFileTXT("TestProduseIn.txt");
    repoFile->loadFromFile();
    RepoUser* repoUser = new RepoUser();
    Service s(repoFile, repoUser);
    string user, parola;
    /*cout << "Dati User: ";
    cin >> user;
    cout << "Dati parola: ";
    cin >> parola;*/
    //if (s.login(user, parola))
    //{
        /*cout << "Scrie ce cauti: ";
        string key;
        cin >> key;
        //cout << key;
        vector<Produs*> rez;
        rez = s.cautInProduse(key);
        cout << endl;
        for (Produs* p : rez)
            cout << p->toString(",")<<endl;
        cout << endl;
        UI ui(s);
        ui.showMenu();

    }*/
    //else
        //cout << "Incorect";

    
    /*RepoFile* repoFile;
    string option;
    // intrebati userul daca vrea txt sau csv
    option = "txt";
    if (option == "txt")
    {
        repoFile = new RepoFileTXT("fisier.txt");
    }
    else
    {
        if (option == "csv")
        {
            repoFile = new RepoFileCSV("fisier.txt");
        }
    }*/
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
