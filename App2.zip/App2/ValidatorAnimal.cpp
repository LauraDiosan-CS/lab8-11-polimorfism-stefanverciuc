#include "ValidatorAnimal.h"
#include "Animal.h"
#include "ValidationException.h"
#include <iostream>

using namespace std;
//
ValidatorAnimal::ValidatorAnimal()
{
}

ValidatorAnimal::~ValidatorAnimal()
{
}

void ValidatorAnimal::validate(Produs* p)
{
	ValidatorProdus::validate(p);
	Animal* pd = (Animal*)p;
	//cout << pd->getVarsta();
	if (pd->getVarsta() <= 0)
	{
		throw ValidationException("Varsta animalului nu poate fi negativa!");
	}
	
}
