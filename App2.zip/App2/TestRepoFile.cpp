#include <assert.h>
#include "TestRepoFile.h"
#include "RepoFileTXT.h"
#include "RepoFileCSV.h"
#include "Animal.h"
#include "Obiect.h"
#include <iostream>

using namespace std;


void TestRepoFile::testRepoFileTXT()
{
	RepoFile* repoFile = new RepoFileTXT("TestProduseIn.txt");
	repoFile->loadFromFile();
	//cout << repoFile->getSize();
	assert(repoFile->getSize() == 2);
	Animal* pd1 = new Animal( "1", "caine" ,30 ,"03.03.2020", 1, 3);
	Obiect* ps2 = new Obiect("123", "lesa", 5, "03.03.2020", 10, "03.03.2020");
	//cout << repoFile->getProdus(0)->toString(" ")<<endl;
	//cout << repoFile->getProdus(1)->toString(" ") << endl;
	assert(*repoFile->getProdus(0) == *pd1->clone());
	assert(*repoFile->getProdus(1) == *ps2->clone());
	//cout << "OK";
	repoFile->setFileName("TestProduseOut.txt");
	repoFile->saveToFile();
}



void TestRepoFile::testGetSize()
{
	RepoFile* repoFile = new RepoFileTXT();
	assert(repoFile->getSize() == 0);
	repoFile->addProdus(new Produs());
	assert(repoFile->getSize() == 1);
}

void TestRepoFile::testGetAll()
{
	RepoFile* repoFile = new RepoFileTXT();
	Animal* p1 = new Animal("123","caine", 3, "03.03.2020",1,3);
	Obiect* p2 = new Obiect("123","lesa", 5, "03.03.2020", 10, "03.03.2020");
	repoFile->addProdus(p1);
	repoFile->addProdus(p2);
	vector<Produs*> produse = repoFile->getAll();
	assert(*produse[0] == *p1->clone());
	assert(*produse[1] == *p2->clone());
}

void TestRepoFile::testGetProdus()
{
	RepoFile* repoFile = new RepoFileTXT();
	Animal* p = new Animal("123", "caine", 3, "03.03.2020", 1, 3);
	repoFile->addProdus(p);
	assert(*repoFile->getProdus(0) == *p->clone());
	assert(*repoFile->getProdus(-1) == *(new Produs()));
	assert(*repoFile->getProdus(1) == *(new Produs()));
}

void TestRepoFile::testAddProdus()
{
	RepoFile* repoFile = new RepoFileTXT();
	Animal* p = new Animal("123", "caine", 3, "03.03.2020", 1, 3);
	repoFile->addProdus(p);
	assert(*repoFile->getProdus(0) == *p->clone());
}

void TestRepoFile::testUpdateProdus()
{
	RepoFile* repoFile = new RepoFileTXT();
	Animal* p1 = new Animal("123", "caine", 3, "03.03.2020", 1, 3);
	repoFile->addProdus(p1);
	Animal* p2 = new Animal("1", "pisica", 5, "03.03.2020", 1,1);
	Animal* p3 = new Animal("2", "papagal", 5, "2009", 1, 1);
	repoFile->updateProdus(p3, p2);
	assert(*repoFile->getProdus(0) == *p1);
	repoFile->updateProdus(p1, p2);
	assert(*repoFile->getProdus(0) == *p2);
}

void TestRepoFile::testDeleteProdus()
{
	RepoFile* repoFile = new RepoFileTXT();
	Animal* p1 = new Animal("123", "caine", 3, "03.03.2020", 1, 3);
	repoFile->addProdus(p1);
	Animal* p2 = new Animal("1", "pisica", 5, "03.03.2020", 1, 1);
	repoFile->deleteProdus(p2);
	assert(repoFile->getSize() == 1);
	assert(*repoFile->getProdus(0) == *p1);
	repoFile->deleteProdus(p1);
	assert(repoFile->getSize() == 0);
}

void TestRepoFile::testLoadFromFileTXT()
{
	RepoFile* repoFile = new RepoFileTXT(this->fileNameInTXT);
	repoFile->loadFromFile();
	assert(repoFile->getSize() == this->produseIn.size());
	//cout << repoFile->getSize();
	//cout << repoFile->getProdus(0)->toString(" ")<<endl;
	//cout << this->produseIn[0]->toString(" ") << endl;
	assert(*repoFile->getProdus(0) == *this->produseIn[0]);
	assert(*repoFile->getProdus(1) == *this->produseIn[1]);
}

void TestRepoFile::testLoadFromFileCSV()
{
	RepoFile* repoFile = new RepoFileCSV(this->fileNameInCSV);
	repoFile->loadFromFile();
	assert(repoFile->getSize() == this->produseIn.size());
	assert(*repoFile->getProdus(0) == *this->produseIn[0]);
	assert(*repoFile->getProdus(1) == *this->produseIn[1]);
}

void TestRepoFile::testSavetoFileTXT()
{
	RepoFile* repoFile = new RepoFileTXT(this->fileNameInTXT);
	repoFile->loadFromFile();
	repoFile->setFileName(this->fileNameOutTXT);
	Animal* newProdus = new Animal("1", "pisica", 5, "03.03.2020", 1, 1);
	repoFile->addProdus(newProdus);
	repoFile->saveToFile();
	repoFile->loadFromFile();
	assert(repoFile->getSize() == this->produseIn.size() + 1);
	vector<Produs*> produse = repoFile->getAll();
	for (int i = 0; i < repoFile->getSize() - 1; i++)
	{
		assert(*produse[i] == *this->produseIn[i]);
	}
	assert(*produse[produse.size() - 1] == *newProdus);
}

void TestRepoFile::testSaveToFileCSV()
{
	RepoFile* repoFile = new RepoFileCSV(this->fileNameInCSV);
	repoFile->loadFromFile();
	repoFile->setFileName(this->fileNameOutCSV);
	Animal* newProdus = new Animal("1", "pisica", 5, "03.03.2020", 1, 1);
	repoFile->addProdus(newProdus);
	repoFile->saveToFile();
	repoFile->loadFromFile();
	assert(repoFile->getSize() == this->produseIn.size() + 1);
	vector<Produs*> produse = repoFile->getAll();
	for (int i = 0; i < repoFile->getSize() - 1; i++)
	{
		assert(*produse[i] == *this->produseIn[i]);
	}
	assert(*produse[produse.size() - 1] == *newProdus);
}

TestRepoFile::TestRepoFile()
{
	Animal* p1 = new Animal("1","caine",30,"03.03.2020",1,3);
	Obiect* p2 = new Obiect("123","lesa",5,"03.03.2020",10,"03.03.2020");
	this->produseIn.push_back(p1);
	this->produseIn.push_back(p2);
}

TestRepoFile::~TestRepoFile()
{
}

void TestRepoFile::testAll()
{
	this->testRepoFileTXT();
	this->testGetSize();
	this->testGetAll();
	this->testGetProdus();
	this->testAddProdus();
	this->testUpdateProdus();
	this->testDeleteProdus();
	this->testLoadFromFileTXT();
	this->testLoadFromFileCSV();
	this->testSavetoFileTXT();
	this->testSaveToFileCSV();
}
